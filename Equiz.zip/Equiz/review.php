<?php
session_start();

extract($_POST);
extract($_SESSION);
include("database.php");
if(isset($submit))
{
  if($submit=='Finish')
  {
  mysqli_query($con,"delete from mst_useranswer where sess_id='" . session_id() ."'") or die(mysqli_error());
  unset($_SESSION['qn']);
  header("Location: home.php");
  exit;
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Result | Equiz</title>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="css/font-awesome.min.css">

    <!-- ElegantFonts CSS -->
    <link rel="stylesheet" href="css/elegant-fonts.css">

    <!-- themify-icons CSS -->
    <link rel="stylesheet" href="css/themify-icons.css">

    <!-- Swiper CSS -->
    <link rel="stylesheet" href="css/swiper.min.css">

    <!-- Styles -->
    <link rel="stylesheet" href="style.css">
    <style type="text/css">

  
#MainDiv
{
  
  width:100%;
  height:100%;
}


#MenuDiv
{ 
  width:100%;
  height:20%;
  float:left;
}


#NavDiv
{
  float:left;
  background-color:#B5CDF6; 
  margin:0px;
  width:100%;
}

.subMenu
{
  float:left;
  padding:10px 10px 10px 10px;
  font-size:20px;
  background-color:transparent;
  color:black;
  
}

.subMenu a
{
  text-decoration:none;
  color:black;
  
}

.subMenu:hover
{
  background-color:transparent;
  color:black;
}

#LogOut
{
  margin-left:1050px;
}

#Login
{
  margin-left:50px;
}



        .contact-form, .contact-info {

    margin-top: 20px;
    margin-left: 50px;
    

}
td{
  padding-left: 10px;
  padding-right: 10px;
}

 .read-more {
    margin-top: 40px;
    width: 200px;
}
}

 .read-more a {
    display: block;
    padding: 12px 40px;
    border: 2px solid #3c8dbc;
    font-size: 13px;
    font-weight: bold;
    color: black;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    text-decoration: none;
}

 .read-more a:hover {
    background: #3c8dbc;
}
    </style>
    <script language="javascript">
function check()
{

 if(document.form1.lid.value=="")
  {
    alert("Plese Enter Login Id");
    document.form1.lid.focus();
    return false;
  }
 
 if(document.form1.pass.value=="")
  {
    alert("Plese Enter Your Password");
    document.form1.pass.focus();
    return false;
  } 
  if(document.form1.cpass.value=="")
  {
    alert("Plese Enter Confirm Password");
    document.form1.cpass.focus();
    return false;
  }
  if(document.form1.pass.value!=document.form1.cpass.value)
  {
    alert("Confirm Password does not matched");
    document.form1.cpass.focus();
    return false;
  }
  if(document.form1.name.value=="")
  {
    alert("Plese Enter Your Name");
    document.form1.name.focus();
    return false;
  }
  if(document.form1.address.value=="")
  {
    alert("Plese Enter Address");
    document.form1.address.focus();
    return false;
  }
  if(document.form1.city.value=="")
  {
    alert("Plese Enter City Name");
    document.form1.city.focus();
    return false;
  }
  if(document.form1.phone.value=="")
  {
    alert("Plese Enter Contact No");
    document.form1.phone.focus();
    return false;
  }
  if(document.form1.email.value=="")
  {
    alert("Plese Enter your Email Address");
    document.form1.email.focus();
    return false;
  }
  e=document.form1.email.value;
        f1=e.indexOf('@');
        f2=e.indexOf('@',f1+1);
        e1=e.indexOf('.');
        e2=e.indexOf('.',e1+1);
        n=e.length;

        if(!(f1>0 && f2==-1 && e1>0 && e2==-1 && f1!=e1+1 && e1!=f1+1 && f1!=n-1 && e1!=n-1))
        {
            alert("Please Enter valid Email");
            document.form1.email.focus();
            return false;
        }
  return true;
  }
  
</script>
</head>
<body style="background: background: background: #E0EAFC;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #CFDEF3, #E0EAFC);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #E0EAFC, #E0EAFC); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
;">
                <div class="contact-form">
                     <h1 style="font-size: 60px;"><b style="color:#3c8dbc;">E</b>quiz</h1><br>

                 <div id="MenuDiv">
      <div id="NavDiv">
        <div class="subMenu"><a href="home.php">Home</a></div>
        <div class="subMenu" id="LogOut"><a href="signout.php">Logout</a></div>
        
      </div>
    </div>
<div style="padding-top: 100px;">
<?php
//include("header.php");
echo "<h1 class=head1> Review Test Question</h1>";

if(!isset($_SESSION['qn']))
{
    $_SESSION['qn']=0;
}
else if($submit=='Next Question' )
{
@  $_SESSION[qn]=$_SESSION[qn]+1;
  
}

@ $rs=mysqli_query($con,"select * from mst_useranswer where sess_id='" . session_id() ."'",$cn) or die(mysqli_error());
@ mysqli_data_seek($rs,$_SESSION[qn]);
$row= mysqli_fetch_row($rs);
echo "<form name=myfm method=post action=review.php>";
echo "<table width=100%> <tr> <td width=30>&nbsp;<td> <table border=0>";
@$n=$_SESSION[qn]+1;
echo "<tR><td><span class=style2>Que ".  $n .": $row[2]</style>";
echo "<tr><td class=".($row[7]==1?'tans':'style8').">1 .$row[3]";
echo "<tr><td class=".($row[7]==2?'tans':'style8').">2 .$row[4]";
echo "<tr><td class=".($row[7]==3?'tans':'style8').">3 .$row[5]";
echo "<tr><td class=".($row[7]==4?'tans':'style8').">4 .$row[6]";
echo "<tr><td class=".($row[7]==5?'tans':'style8')."><b>Ans : $row[7]</b>";

if($_SESSION['qn']<mysqli_num_rows($rs)-1)
echo "<tr><td><input type=submit name=submit value='Next Question'></form>";
else
echo "<tr><td><input type=submit name=submit value='Finish'></form>";

echo "</table></table>";
?>

  
</div>
                </div><!-- .contact-form -->
            </div><!-- .col -->

            

    <script type='text/javascript' src='js/jquery.js'></script>
    <script type='text/javascript' src='js/swiper.min.js'></script>
    <script type='text/javascript' src='js/masonry.pkgd.min.js'></script>
    <script type='text/javascript' src='js/jquery.collapsible.min.js'></script>
    <script type='text/javascript' src='js/custom.js'></script>

</body>
</html>