<!DOCTYPE html>
<html lang="en">
<head>
    <title>Singup | Equiz</title>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="css/font-awesome.min.css">

    <!-- ElegantFonts CSS -->
    <link rel="stylesheet" href="css/elegant-fonts.css">

    <!-- themify-icons CSS -->
    <link rel="stylesheet" href="css/themify-icons.css">

    <!-- Swiper CSS -->
    <link rel="stylesheet" href="css/swiper.min.css">

    <!-- Styles -->
    <link rel="stylesheet" href="style.css">
    <style type="text/css">
        .contact-form, .contact-info {

    margin-top: 20px;
    margin-left: 70px;
    margin-right: 100px; 

}
 .read-more {
    margin-top: 40px;
    width: 200px;
}

 .read-more a {
    display: block;
    padding: 12px 40px;
    border: 2px solid #3c8dbc;
    font-size: 13px;
    font-weight: bold;
    color: black;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    text-decoration: none;
}

 .read-more a:hover {
    background: #3c8dbc;
}
    </style>
    <script language="javascript">
function check()
{

 if(document.form1.lid.value=="")
  {
    alert("Plese Enter Login Id");
    document.form1.lid.focus();
    return false;
  }
 
 if(document.form1.pass.value=="")
  {
    alert("Plese Enter Your Password");
    document.form1.pass.focus();
    return false;
  } 
  if(document.form1.cpass.value=="")
  {
    alert("Plese Enter Confirm Password");
    document.form1.cpass.focus();
    return false;
  }
  if(document.form1.pass.value!=document.form1.cpass.value)
  {
    alert("Confirm Password does not matched");
    document.form1.cpass.focus();
    return false;
  }
  if(document.form1.name.value=="")
  {
    alert("Plese Enter Your Name");
    document.form1.name.focus();
    return false;
  }
  if(document.form1.address.value=="")
  {
    alert("Plese Enter Address");
    document.form1.address.focus();
    return false;
  }
  if(document.form1.city.value=="")
  {
    alert("Plese Enter City Name");
    document.form1.city.focus();
    return false;
  }
  if(document.form1.phone.value=="")
  {
    alert("Plese Enter Contact No");
    document.form1.phone.focus();
    return false;
  }
  if(document.form1.email.value=="")
  {
    alert("Plese Enter your Email Address");
    document.form1.email.focus();
    return false;
  }
  e=document.form1.email.value;
        f1=e.indexOf('@');
        f2=e.indexOf('@',f1+1);
        e1=e.indexOf('.');
        e2=e.indexOf('.',e1+1);
        n=e.length;

        if(!(f1>0 && f2==-1 && e1>0 && e2==-1 && f1!=e1+1 && e1!=f1+1 && f1!=n-1 && e1!=n-1))
        {
            alert("Please Enter valid Email");
            document.form1.email.focus();
            return false;
        }
  return true;
  }
  
</script>
</head>
<body style="background: background: background: #E0EAFC;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #CFDEF3, #E0EAFC);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #E0EAFC, #E0EAFC); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
;">
                <div class="contact-form">
                     <h1 style="font-size: 60px;"><b style="color:#3c8dbc;">E</b>quiz</h1><br>

                   <?php
//include("header.php");
extract($_POST);
include("database.php");
$rs=mysqli_query($con,"select * from mst_user where login='$lid'");
if (mysqli_num_rows($rs)>0)
{
  echo "<br><br><br><div class=head1><h3>Login Id Already Exists</h3>


  <footer class="." read-more".">
                                <div class="."row".">
                                    <div class="."col-8"."><a href="."signup.php".">Back </a></div>
                            </div>
                            </footer>
                  </div>";
  exit;
}
@$query="insert into mst_user(user_id,login,pass,username,address,city,phone,email) values('$uid','$lid','$pass','$name','$address','$city','$phone','$email')";
$rs=mysqli_query($con,$query)or die("Could Not Perform the Query");
echo "<br><div class=head1><h3>Your Login ID  $lid Created Sucessfully</h3></div>";
echo "<br><div class=head1><h3>Please Login using your Login ID to take Quiz</h3></div>";
echo "
<footer class="." read-more".">
                                <div class="."row".">
                                    <div class="."col-8"."><a href="."login.php".">Login </a></div>
                            </div>
                            </footer>
";


?>
                </div><!-- .contact-form -->
            </div><!-- .col -->

            

    <script type='text/javascript' src='js/jquery.js'></script>
    <script type='text/javascript' src='js/swiper.min.js'></script>
    <script type='text/javascript' src='js/masonry.pkgd.min.js'></script>
    <script type='text/javascript' src='js/jquery.collapsible.min.js'></script>
    <script type='text/javascript' src='js/custom.js'></script>

</body>
</html>