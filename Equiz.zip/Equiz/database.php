<?php 
$con=mysqli_connect("localhost","root","","quiz_new") or die('Database not connected');
?>