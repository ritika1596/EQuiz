<?php
session_start();
error_reporting(1);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Equiz | Log in</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <style>
  .login-page, .register-page {

    background: background: #E0EAFC;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #CFDEF3, #E0EAFC);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #3c8dbc, #E0EAFC); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
;
    overflow: hidden !important;

}
.login-box-body, .register-box-body {

    background: #ffffff80;
    padding: 20px;
    border-top: 0;
    color: #666;

}
  </style>
</head>
<body class="hold-transition login-page">
<?php
//print_r($_POST);die;
//include("header.php");
include("../database.php");
extract($_POST);
if(isset($submit))
{
	$rs=mysqli_query($con,"select * from mst_admin where loginid='$loginid' and pass='$pass'",$cn) or die(mysqli_error());
	if(mysqli_num_rows($rs)<1)
	{
		echo "


			<body class="."hold-transition login-page".">
<div class="."login-box".">
  <div class="."login-logo".">
    <a href="."#"."><b>E</b>quiz</a>
  </div>
  <div class="."login-box-body".">
    <p class="."login-box-msg"."><b>Invalid User Name or Password<b><br>
		<a href='index.php'>Click here to login again </a></p>";
	//exit;
		//echo "<script>window.location='index.php'</script>";		
	}
	else
	{
	echo "<script>window.location='Dashboard.php'</script>";			
	$_SESSION['alogin']="true";
	}
}
else if(!isset($_SESSION[alogin]))
{
	echo "<BR><BR><BR><BR><div class=head1> Your are not logged in<br> Please <a href=index.php>Login</a><div>";
		exit;
}

		//echo"<h1 class='text-center bg-danger'>Welcome to Admistrative Area</h1>";	



	//echo"<div style='background:#CDDC39;padding:49PX;margin-top:33px;margin-right:20px;border-radius:500px'> ";
			
		


?>



</body>
</html>
