<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Home | ADMIN Equiz</title><meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<style>
.login-page, .register-page {

    background: linear-gradient(to right, #CFDEF3, #E0EAFC) !important;

}
</style>
</head>
<body class="hold-transition skin-blue sidebar-mini" style="overflow-y: scroll;">
<div class="wrapper">

  <header class="main-header">
    <a href="#" class="logo">
      <span class="logo-mini"><b>E</b>Q</span>
      <span class="logo-lg"><b>E</b>quiz</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
                   
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="dist/img/avatar.png" class="user-image" alt="User Image">
              <span class="hidden-xs">ADMIN</span>
            </a>
            <ul class="dropdown-menu">
              <li class="user-header">
                <img src="dist/img/avatar.png" class="img-circle" alt="User Image">

                <p>
                  ADMIN
                  
                </p>
              </li>
              <li class="user-footer">
                <div class="pull-right">
                  <a href="signout.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
           </ul>
      </div>
    </nav>
  </header>

  <aside class="main-sidebar">
    <section class="sidebar">
      <div class="user-panel">
        <div class="pull-left image">
          <img src="dist/img/avatar.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>ADMIN</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li>
          <a href="Dashboard.php">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="treeview active">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Add Options</span>
            <span class="pull-right-container">
              
            </span>
          </a>
          <ul class="treeview-menu">
            <li ><a href="viewsub.php"><i class="fa fa-circle-o"></i>Subject</a></li>
            <li ><a href="testview.php"><i class="fa fa-circle-o"></i>Test</a></li>
            <li class="active"><a href="questiondelete.php"><i class="fa fa-circle-o"></i>Question</a></li>
          </ul>
        </li>
        <li>
          <a href="showuser.php">
            <i class="fa fa-users"></i> <span>Users</span>
          </a>
        </li>
 
      </ul>
    </section>
    </aside>
<div class="content-wrapper">
    <section class="content-header">
      <h1>
        Question
      </h1>
      <ol class="breadcrumb">
        <li><i class="fa fa-dashboard"></i> Home</li>
        <li class="active"> Question</li>
      </ol>
    </section>

    <section class="content">

      <div class="box">
       
        <div class="box-body">
         <a class='btn btn-danger' href='questionadd.php'>Add Question</a>
       </div>
        <div class="box-footer">
<?php
//include("header.php");
include("../database.php");
{
$sql=mysqli_query($con,"select * from mst_question"); 
  
  echo "<table class='table table-striped'>";
  echo "<tr><th class='text-primary'>ID</th><th class='text-primary'>Question</th>
  <th class='text-primary'>Update</th>
  <th class='text-primary'>Delete</th></tR>";
  
  while($result=mysqli_fetch_assoc($sql))
  {
$id=$result['que_id'];
  
  echo "<tr>";  
  echo "<td>".$result['que_id']. "</td>";
  echo "<td>".$result['que_desc']."</td>";
  echo "<td><a href='queupdate.php?que_id=$id'><span class='glyphicon glyphicon-edit'></span></a></td>";
  echo "<td><a href='quedelete.php?que_id=$id'><span class='glyphicon glyphicon-trash'></span></a></td>";
  echo "</tr>";
  }
  echo "</table>";
}
?>

        </div>
        </div>
      
    </section>
     </div>
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2019-2020 <a href="#">VCACS</a>.</strong> All rights
    reserved.
  </footer>

  <div class="control-sidebar-bg"></div>
</div>
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<script src="dist/js/adminlte.min.js"></script>
<script src="dist/js/demo.js"></script>
<script>
  $(document).ready(function () {
    $('.sidebar-menu').tree()
  })
</script>
</body>
</html>
